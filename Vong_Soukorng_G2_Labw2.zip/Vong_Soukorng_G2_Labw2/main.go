package main

func main() {
	lab1()
	lab2()
	lab3()
	lab4()
	lab5()
	lab6()
}
